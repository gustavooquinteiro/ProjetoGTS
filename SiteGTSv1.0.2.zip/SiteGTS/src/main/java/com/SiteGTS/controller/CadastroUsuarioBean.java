package com.SiteGTS.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.bean.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.SiteGTS.model.Grupo;
import com.SiteGTS.model.Usuario;
import com.SiteGTS.repository.Usuarios;
import com.SiteGTS.service.CadastroUsuarioService;
import com.SiteGTS.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroUsuarioBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private CadastroUsuarioService cus;

	private Usuario user;

	private List<Grupo> grupoList;

	private Grupo grupo;

	@Inject
	private Usuarios usuarios;

	public CadastroUsuarioBean() {
		limpar();
	}

	private void limpar() {
		user = new Usuario();
	}
	
/*
	public List<Grupo> listarGrupos(String role) {
		grupoList = usuarios.buscar(role);
		return grupoList;
	}*/

	public void salvar() {
		cus.salvar(user);
		limpar();
		FacesUtil.addInfoMessage("Cadastro feito com sucesso!!");
	}

	public Usuario getUser() {
		return user;
	}

	public void setUser(Usuario user) {
		this.user = user;
	}

	public Grupo getGrupo() {
		return grupo;
	}

	public void setGrupo(Grupo grupo) {
		this.grupo = grupo;
	}
}