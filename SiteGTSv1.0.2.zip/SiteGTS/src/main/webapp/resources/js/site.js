var posicaoPlacar =$("#cadastro:botaoSalvar").offset().top;
$("body").animate({
	scrollTop: posicaoPlacar + "px"; 	
}, 1000);
